# NASA and JPL data sources

Every external value in the game carries a provenance label in the interface:

| Label | Meaning |
|---|---|
| `NASA source` | came from a cited NASA table or API, citation shown inline |
| `LIVE` | fetched from the NASA/JPL endpoint this session |
| `CACHED` | served from our cache layer because the live call failed or was rate-limited |
| `DEMO DATA` | bundled snapshot; the live source was unreachable and the app says so |
| `game estimate` | simplified educational mechanic, never presented as a validated design |

## Live services

| Service | Endpoint | Used for |
|---|---|---|
| NASA APOD | `https://api.nasa.gov/planetary/apod` | Daily astronomy briefing |
| NASA NeoWs | `https://api.nasa.gov/neo/rest/v1/feed` | Close approaches → debris-hazard field |
| NASA DONKI — Solar Flare | `https://api.nasa.gov/DONKI/FLR` | Space-weather station in the GO / HOLD poll — the only live source that changes gameplay |
| NASA Image and Video Library | `https://images-api.nasa.gov/search` | Destination imagery |
| JPL Horizons | `https://ssd.jpl.nasa.gov/api/horizons.api` | Planet positions, Earth→target distance, light-time |

All keys stay server-side. The browser never receives a NASA key.

## Published NASA reference values

| Reference | Used for |
|---|---|
| NASA NSSDCA planetary fact sheets | Diameter, gravity, rotation, orbital period, distance from the Sun |
| NASA SLS Block 1 / Orion | Launch-vehicle lift limit and staged-ascent events |
| NASA Glenn RL10 | Cryogenic upper-stage performance |
| NASA Dawn NSTAR | Ion thruster thrust and specific impulse |
| NASA Glenn NERVA | Nuclear thermal reference performance |
| NASA RPS MMRTG | Radioisotope power output and decay |

## Connected but not surfaced

DSCOVR EPIC, Mars Rover Photos, JPL Small-Body Database and JPL Sentry are wired into the server proxy but are not used on any screen. We declare them rather than claim coverage we do not have.

## Media

NASA imagery and NASA 3D Resources models are used under the [NASA Media Usage Guidelines](https://www.nasa.gov/nasa-brand-center/images-and-media/), credited in-app. No NASA insignia is used as project branding, and nothing here implies NASA endorsement.
