# Known limitations

We would rather list these than have a judge find them.

## Physics and numbers

- **Δv and transit times are simplified**, not solved trajectories. They are close enough to teach the trade-off, and they are labelled `game estimate` wherever they appear.
- **The 3D solar system compresses distances** so the whole system is visible; scale is not linear and the interface says so.
- **The route map is illustrative.** It shows the shape of a Hohmann transfer, not a numerically integrated path.
- **Planet constants are rounded** to the precision a player needs; the source is the NASA NSSDCA fact sheet cited in `data-sources.md`.

## Rules and scoring

- **Readiness, hazards and scoring are game rules**, not NASA flight rules. They are modelled on real engineering practice — mass margin, power margin, thermal limits, range safety — but they are not a real flight-readiness review.
- **The launch sequence runs on a compressed timeline.** A real SLS ascent does not finish in the time the game shows.
- **The debrief is a rubric**, not a certification. It scores the decisions a player made against the mission they chose.

## Data

- Five NASA/JPL services are live (APOD, NeoWs, DONKI, NASA Image and Video Library, JPL Horizons). If a call fails, or the network blocks it, the app falls back to bundled snapshots and **labels the data `DEMO DATA`** rather than pretending it is live.
- **DSCOVR EPIC, Mars Rover Photos, JPL SBDB and JPL Sentry are connected in the server proxy but not surfaced on any screen.** We declare that instead of implying we use them.
- DONKI's flare feed is the only live source that changes gameplay; the others inform the scene and the briefing.

## Product

- **No accounts, no leaderboards, no saved progress across devices.** Missions are archived locally for comparison in the same browser.
- **Six languages are shipped, but review depth varies**: English is fully reviewed; the other five cover the interface and the core mission text, and may read awkwardly in places.
- **The 3D hub is best on desktop** with a keyboard. It runs on mobile, but the hub is the weakest experience there; the mission flow itself works fine.
- **No offline install.** The mission runs without NASA keys using `DEMO_KEY`, but the first load needs a network connection.

## What we would fix next

Teacher mode with class codes and printable debriefs; exportable mission logs so a teacher can assess a decision trace rather than a final score; more worlds and vehicles; and a reviewed translation pass for all six languages with regional classrooms.
