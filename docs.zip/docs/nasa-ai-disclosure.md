# Super Intelligence (SI) disclosure — detail

This is the detailed version of [`../AI_USE.md`](../AI_USE.md), written to match the 2026 Space Apps Project Submission Guide's SI requirements for each media type.

## Code and data — acknowledged in text and metadata

- **Code:** generated and edited with an SI application builder (Lovable) under team direction. The team specified mechanics, numbers, screen flow and constraints; reviewed every build in the live preview; and tested the full mission before accepting it. Acknowledged here, in `README.md`, in `../TECH-STACK-AND-CREDITS.md`, and in the *Use of Super Intelligence (SI)* answer on the submission page.
- **Data:** every NASA/JPL value is fetched at run time from the cited endpoint, or taken from a cited published NASA reference. **No NASA value was produced by an SI model.** Where a value is a simplification, the interface labels it `game estimate`; where it comes from NASA it reads `NASA source`; when a live call fails the app labels the fallback `DEMO DATA`.
- **No NASA branding:** SI output was never used to create, modify or imitate NASA logos, flags, mission identifiers or brand elements. None appear in the app or the media.

## Audio — acknowledged in descriptive text and metadata

- The narration in the 28-second demo and the extended walkthrough is **AI text-to-speech reading a script the team wrote and verified**.
- Acknowledged in: the video description and every submission field that links it, the MP4 metadata (`comment`, `description`, `artist`), `AI_USE.md`, and this file.
- The in-app mentor uses the browser `speechSynthesis` API — no model, no cloud call, no audio file shipped.

## Images and video — watermarked where SI is involved

- **No frame of the demo video and no screenshot is SI-generated.** All are captures of the running application.
- Because the video's audio is SI, the video carries a **visible on-screen label on every frame**: *"AI-assisted narration and SI-assisted development — disclosed"*.
- In-app 3D geometry and scenes are generated in code at run time, not from generated imagery.

## What SI was not used for

- Not used to choose the challenge or invent the idea.
- Not used to produce NASA data, citations or measurements.
- Not used to create any image of a person, and no person under 18 appears anywhere in the project, the demo or the screenshots.

## Team sign-off

Declared by Rehan Shaikh, Team Lead, on behalf of all six members: Rehan Shaikh, Shubham Rajendra Tanpure, Omkar Maruti Karad, Tejas Bhaurav Thombare, Tejas Dhavane, Atharav Joshi.
