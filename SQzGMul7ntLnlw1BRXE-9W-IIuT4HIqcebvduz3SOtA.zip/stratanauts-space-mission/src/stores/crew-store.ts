import { create } from "zustand";
import { persist } from "zustand/middleware";
import { activeRoles, ROLES, type RoleId } from "../lib/crew";

export type Vote = "go" | "nogo";

export interface CrewLogEntry {
  role: RoleId;
  text: string;
  at: number;
}

type CrewState = {
  enabled: boolean;
  size: number;
  names: Record<RoleId, string>;
  active: RoleId;
  votes: Record<RoleId, Vote | null>;
  log: CrewLogEntry[];
  enable: (on: boolean) => void;
  setSize: (n: number) => void;
  setName: (role: RoleId, name: string) => void;
  passTo: (role: RoleId) => void;
  next: () => void;
  vote: (role: RoleId, v: Vote) => void;
  clearVotes: () => void;
  record: (role: RoleId, text: string) => void;
  reset: () => void;
};

const defaultNames = Object.fromEntries(ROLES.map((r) => [r.id, r.name])) as Record<RoleId, string>;
const emptyVotes = Object.fromEntries(ROLES.map((r) => [r.id, null])) as Record<RoleId, Vote | null>;

export const useCrewStore = create<CrewState>()(
  persist(
    (set, get) => ({
      enabled: false,
      size: 4,
      names: { ...defaultNames },
      active: "fd" as RoleId,
      votes: { ...emptyVotes },
      log: [],

      enable: (on) => set({ enabled: on, votes: { ...emptyVotes }, log: on ? get().log : [] }),
      setSize: (n) => {
        const size = Math.max(1, Math.min(4, n));
        const roles = activeRoles(size);
        const active = roles.includes(get().active) ? get().active : (roles[0] as RoleId);
        set({ size, active });
      },
      setName: (role, name) => set((s) => ({ names: { ...s.names, [role]: name } })),
      passTo: (role) => set({ active: role }),
      next: () => {
        const roles = activeRoles(get().size);
        const i = roles.indexOf(get().active);
        set({ active: roles[(i + 1) % roles.length] as RoleId });
      },
      vote: (role, v) => set((s) => ({ votes: { ...s.votes, [role]: v } })),
      clearVotes: () => set({ votes: { ...emptyVotes } }),
      record: (role, text) => set((s) => ({ log: [...s.log, { role, text, at: Date.now() }].slice(-40) })),
      reset: () => set({ enabled: false, size: 4, names: { ...defaultNames }, active: "fd", votes: { ...emptyVotes }, log: [] }),
    }),
    {
      name: "stratanauts-crew",
      partialize: (s) => {
        const { enable: _a, setSize: _b, setName: _c, passTo: _d, next: _e, vote: _f, clearVotes: _g, record: _h, reset: _i, ...rest } = s;
        void _a; void _b; void _c; void _d; void _e; void _f; void _g; void _h; void _i;
        return rest as never;
      },
    },
  ),
);
