// Crew mode — up to four participants, each with a distinct role and its own decisions.
// Roles mirror a real flight team: flight director, spacecraft engineer, science lead, comms & ops.

export type RoleId = "fd" | "eng" | "sci" | "ops";

export interface Role {
  id: RoleId;
  name: string;
  short: string;
  desk: string;
  owns: string;
  duty: string;
  color: string;
  glyph: string;
}

export const ROLES: Role[] = [
  {
    id: "fd",
    name: "Flight Director",
    short: "FLIGHT",
    desk: "Mission Control",
    owns: "Destination, trajectory and budget",
    duty: "You decide where we go, how we get there, and what we are allowed to spend. Every other decision has to fit inside the budget and the Δv you commit to.",
    color: "#38bdf8",
    glyph: "◈",
  },
  {
    id: "eng",
    name: "Spacecraft Engineer",
    short: "ENGINE",
    desk: "Vehicle Systems",
    owns: "Propulsion, fuel, power and structure",
    duty: "You turn the Flight Director's trajectory into hardware: engines, tanks, solar wings, RTGs and batteries. Mass you add is Δv the mission loses.",
    color: "#f59e0b",
    glyph: "⚙",
  },
  {
    id: "sci",
    name: "Science Lead",
    short: "SCIENCE",
    desk: "Payload & Objectives",
    owns: "Science objective and instrument payload",
    duty: "You decide what the mission is actually for, and which instruments fly. Every instrument buys science with mass, power, data volume and money.",
    color: "#a78bfa",
    glyph: "✦",
  },
  {
    id: "ops",
    name: "Comms & Ops",
    short: "COMMS",
    desk: "Operations",
    owns: "Antennas, shielding and launch readiness",
    duty: "You keep the spacecraft talking and alive: antenna count, radiation shielding, and the final GO/NO-GO call on launch day.",
    color: "#34d399",
    glyph: "⌁",
  },
];

const [FIRST_ROLE] = ROLES;
export const roleById = (id: RoleId): Role => ROLES.find((r) => r.id === id) ?? (FIRST_ROLE as Role);

/** Which role owns the decision made on each design phase. */
export const PHASE_OWNER: Record<string, RoleId> = {
  missions: "fd",
  route: "fd",
  routePreview: "fd",
  budget: "fd",
  overview: "fd",
  brief: "sci",
  objectives: "sci",
  instruments: "sci",
  fuel: "eng",
  power: "eng",
  craft: "eng",
  build: "eng",
  comms: "ops",
};

/** Phases where the whole crew votes together instead of one owner deciding. */
export const VOTE_PHASES: string[] = ["check"];

export const ownerOf = (phase: string): RoleId | null => PHASE_OWNER[phase] ?? null;

/** The roles that are in play for a given crew size (1–4). */
export const activeRoles = (size: number): RoleId[] => ROLES.slice(0, Math.max(1, Math.min(4, size))).map((r) => r.id);
