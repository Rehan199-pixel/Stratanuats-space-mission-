import { useState } from "react";
import { ArrowLeft, ArrowRight, Users } from "lucide-react";
import { Button } from "../ui/button";
import { ROLES, activeRoles, roleById, type RoleId } from "../../lib/crew";
import { useCrewStore } from "../../stores/crew-store";
import { useMissionStore } from "../../stores/mission-store";

const SIZES = [1, 2, 3, 4] as const;

/** Crew briefing: pick how many people are flying this mission and who is taking which seat. */
export function CrewSetup() {
  const s = useMissionStore();
  const crew = useCrewStore();
  const [size, setSize] = useState<number>(crew.size);

  const roles = activeRoles(size);
  const begin = () => {
    crew.setSize(size);
    crew.enable(true);
    crew.clearVotes();
    crew.record("fd", `Crew of ${size} briefed for ${s.mission}.`);
    s.newRun("missions");
  };

  return (
    <div className="gm-screen gm-flow">
      <header className="gm-header">
        <Button variant="ghost" className="gm-mark" onClick={() => s.go("menu")} aria-label="Home">
          ◈ <strong>STRATANAUTS <span>SPACE MISSION</span></strong>
        </Button>
        <div className="gm-flow-progress">
          <span>CREW</span>
          <div><i style={{ width: "100%" }} /></div>
          <b>Crew briefing</b>
        </div>
        <div className="gm-header-tools"><span className="gm-signal">Co-op mode</span></div>
      </header>

      <main className="gm-flow-main">
        <aside className="gm-flow-panel">
          <div className="gm-flow-scroll">
            <p className="gm-kicker">Step 1 — assemble the crew</p>
            <h1>Who is flying this mission?</h1>
            <div className="gm-flow-info">
              <p>
                A real mission is not designed by one person. Split the work the way a flight team does: each role owns
                its own decisions, and every choice lands on someone else&apos;s budget.
              </p>
            </div>

            <div className="gm-flow-choices">
              <div className="crew-size-row">
                {SIZES.map((n) => (
                  <Button
                    key={n}
                    variant="ghost"
                    aria-pressed={size === n}
                    className={`gm-choice ${size === n ? "on" : ""}`}
                    onClick={() => setSize(n)}
                  >
                    <span>
                      {n === 1 ? "Solo" : `${n} players`}
                      <small>{n === 1 ? "One person takes every seat" : `${n} seats, pass one device`}</small>
                    </span>
                    {size === n && <Users size={16} />}
                  </Button>
                ))}
              </div>

              <div className="crew-role-list">
                {ROLES.map((r) => {
                  const on = roles.includes(r.id);
                  return (
                    <div key={r.id} className={`crew-role-card ${on ? "on" : "off"}`} style={{ ["--crew-color" as string]: r.color }}>
                      <div className="crew-role-head">
                        <span className="crew-glyph">{r.glyph}</span>
                        <div>
                          <b>{r.name}</b>
                          <small>{r.desk}</small>
                        </div>
                        {!on && <em>empty seat</em>}
                      </div>
                      {on ? (
                        <>
                          <label className="crew-name-field">
                            <span>Player name</span>
                            <input
                              value={crew.names[r.id]}
                              placeholder={r.name}
                              maxLength={22}
                              onChange={(e) => crew.setName(r.id, e.target.value)}
                            />
                          </label>
                          <p className="crew-owns"><b>Owns:</b> {r.owns}</p>
                          <p className="crew-duty">{r.duty}</p>
                        </>
                      ) : (
                        <p className="crew-duty">
                          Add a {(r.id === "ops" ? "fourth" : r.id === "sci" ? "third" : "second")} player to fill this seat —
                          otherwise the Flight Director absorbs these decisions.
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <footer className="gm-flow-actions">
            <Button variant="ghost" onClick={() => s.go("menu")}><ArrowLeft /> Back</Button>
            <Button onClick={begin}>Begin mission <ArrowRight /></Button>
          </footer>
        </aside>

        <div className="gm-flow-stage">
          <div className="crew-brief-note">
            <p className="gm-kicker">How co-op works</p>
            <ol>
              <li>Each design step belongs to one role. The screen shows whose call it is.</li>
              <li>Pass the device to that player when prompted — they decide, the crew lives with it.</li>
              <li>At the launch poll every role votes <b>GO</b> or <b>NO-GO</b>. The mission only launches on a clean poll.</li>
              <li>Solo play works exactly the same, with the Flight Director holding every seat.</li>
            </ol>
            <p className="gm-source">
              Roles mirror a real flight team: Flight Director · Spacecraft Engineer · Science Lead · Comms &amp; Ops.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}

/** Small persistent badge showing which role is on the clock. */
export function CrewChip() {
  const crew = useCrewStore();
  if (!crew.enabled) return null;
  const roles = activeRoles(crew.size);
  return (
    <span className="crew-chip" title="Crew mode">
      <Users size={14} />
      <b>{roles.length}</b>
      <i>{roleById(crew.active).short}</i>
    </span>
  );
}

export function crewName(role: RoleId): string {
  const n = useCrewStore.getState().names[role];
  return (n && n.trim()) || roleById(role).name;
}
