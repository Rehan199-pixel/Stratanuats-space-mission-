import { useCrewStore } from "../../stores/crew-store";
import { useMissionStore } from "../../stores/mission-store";
import { activeRoles, ownerOf, roleById, type RoleId } from "../../lib/crew";
import { Button } from "../ui/button";
import { ArrowRight } from "lucide-react";

const nameOf = (role: RoleId, names: Record<RoleId, string>) =>
  (names[role] && names[role].trim()) || roleById(role).name;

/** Role pips for the header: who is on the clock, and who owns this step. */
export function CrewPips({ phase }: { phase: string }) {
  const crew = useCrewStore();
  if (!crew.enabled) return null;
  const roles = activeRoles(crew.size);
  const owner = ownerOf(phase);
  return (
    <span className="crew-pips" aria-label="Crew roles">
      {roles.map((r) => {
        const role = roleById(r);
        const isActive = r === crew.active;
        const isOwner = r === owner;
        return (
          <i
            key={r}
            className={`crew-pip ${isActive ? "active" : ""} ${isOwner ? "owner" : ""}`}
            style={{ ["--crew-color" as string]: role.color }}
            title={`${nameOf(r, crew.names)} — ${role.name}${isOwner ? " (owns this step)" : ""}`}
          >
            {role.glyph}
          </i>
        );
      })}
    </span>
  );
}

/**
 * Turn gate. When the current design step belongs to another role, the crew is asked to pass
 * the device. One tap, no dead ends — this is what makes the roles real rather than cosmetic.
 */
export function CrewHandoff({ phase }: { phase: string }) {
  const crew = useCrewStore();
  const s = useMissionStore();
  if (!crew.enabled) return null;

  const owner = ownerOf(phase);
  if (!owner) return null;
  const roles = activeRoles(crew.size);
  if (!roles.includes(owner)) return null;              // seat empty — Flight Director absorbs it
  if (owner === crew.active) return null;               // correct player already on the clock

  const role = roleById(owner);
  const who = nameOf(owner, crew.names);

  const handOver = () => {
    crew.passTo(owner);
    crew.record(owner, `Took the ${role.name} seat for ${phase}.`);
    s.say(`${who} is on the clock — ${role.owns.toLowerCase()}.`, "info");
  };

  return (
    <div className="gm-backdrop crew-handoff-backdrop">
      <section className="gm-dialog crew-handoff" onClick={(e) => e.stopPropagation()} style={{ ["--crew-color" as string]: role.color }}>
        <span className="crew-handoff-glyph">{role.glyph}</span>
        <p className="gm-kicker">Pass the device</p>
        <h2>{who}</h2>
        <p className="crew-handoff-role">{role.name} · {role.desk}</p>
        <p className="crew-handoff-duty">{role.duty}</p>
        <p className="crew-handoff-note">
          This step belongs to the <b>{role.name}</b>. Everyone else advises — they decide.
        </p>
        <Button onClick={handOver}>I&apos;m {who} <ArrowRight /></Button>
      </section>
    </div>
  );
}

/** Read-only crew summary used on the mission report so the team sees who decided what. */
export function useCrewSummary() {
  const crew = useCrewStore();
  return activeRoles(crew.size).map((r) => ({
    id: r,
    role: roleById(r),
    name: nameOf(r, crew.names),
    decisions: crew.log.filter((l) => l.role === r).length,
  }));
}
