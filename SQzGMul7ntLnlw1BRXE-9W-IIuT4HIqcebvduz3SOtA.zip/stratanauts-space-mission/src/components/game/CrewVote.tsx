import { useEffect } from "react";
import { Check, X } from "lucide-react";
import { Button } from "../ui/button";
import { useCrewStore } from "../../stores/crew-store";
import { activeRoles, roleById, type RoleId } from "../../lib/crew";

const nameOf = (role: RoleId, names: Record<RoleId, string>) =>
  (names[role] && names[role].trim()) || roleById(role).name;

/**
 * Crew GO/NO-GO poll. Every seat votes on launch day. The mission only leaves the pad on a
 * clean poll — a single NO-GO holds the launch and names who called it.
 */
export function CrewVote({ onReady }: { onReady: (ok: boolean) => void }) {
  const crew = useCrewStore();
  const roles = activeRoles(crew.size);
  const votes = crew.votes;

  const enabled = crew.enabled;
  const pending = roles.filter((r) => !votes[r]);
  const current = enabled ? (pending[0] ?? null) : null;
  const nays = roles.filter((r) => votes[r] === "nogo");
  const allVoted = pending.length === 0;
  // Solo / crew mode off: the poll is not a gate.
  const ok = !enabled || (allVoted && nays.length === 0);

  useEffect(() => {
    onReady(ok);
  }, [ok, onReady]);

  // Pass the device along automatically so each player votes in turn.
  useEffect(() => {
    if (enabled && current && crew.active !== current) crew.passTo(current);
  }, [enabled, current, crew.active, crew]);

  if (!enabled) return null;

  return (
    <section className="crew-vote" aria-live="polite">
      <header className="crew-vote-head">
        <span>Crew launch poll</span>
        <b>{roles.length - pending.length} / {roles.length} voted</b>
      </header>

      <ul>
        {roles.map((r) => {
          const role = roleById(r);
          const v = votes[r];
          const isCurrent = r === current;
          return (
            <li
              key={r}
              className={`crew-vote-row ${v === "go" ? "go" : v === "nogo" ? "nogo" : ""} ${isCurrent ? "current" : ""}`}
              style={{ ["--crew-color" as string]: role.color }}
            >
              <span className="crew-vote-who">
                <i>{role.glyph}</i>
                <b>{nameOf(r, crew.names)}</b>
                <small>{role.short}</small>
              </span>

              {v ? (
                <em className={v}>
                  {v === "go" ? <><Check size={14} /> GO</> : <><X size={14} /> NO-GO</>}
                </em>
              ) : isCurrent ? (
                <span className="crew-vote-buttons">
                  <Button size="sm" variant="secondary" onClick={() => { crew.vote(r, "nogo"); crew.record(r, "Called NO-GO at the launch poll."); }}>
                    NO-GO
                  </Button>
                  <Button size="sm" onClick={() => { crew.vote(r, "go"); crew.record(r, "Voted GO at the launch poll."); }}>
                    GO
                  </Button>
                </span>
              ) : (
                <em className="waiting">waiting</em>
              )}
            </li>
          );
        })}
      </ul>

      {allVoted && nays.length > 0 && (
        <p className="crew-vote-note nogo">
          Launch held — {nays.map((r) => nameOf(r, crew.names)).join(", ")} called NO-GO. Fix the design or talk them round.
        </p>
      )}
      {ok && <p className="crew-vote-note go">All seats GO. Flight Director has the launch.</p>}
    </section>
  );
}
