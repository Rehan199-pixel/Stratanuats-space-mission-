# Stratanauts Space Mission — your project

**Location:** `stratanauts-space-mission/` (workspace root)
**Running now:** port 8080 — see the live preview
**Status:** TypeScript clean (`npx tsc --noEmit` → 0 errors), all modules compile, home page HTTP 200

---

## Why it "wasn't working" before

Two separate things, both now fixed:

1. **`node_modules` is not saved in this workspace.** It's excluded from snapshots, so every new session the app had no dependencies and `npm run dev` couldn't start. Fixed by re-running `npm install`. **This will happen again in a new session — just run `npm install` first.**
2. **The rename had only touched README and docs**, not the running app, and the crew screen was never wired into the phase router. Both fixed.

---

## Run it

```bash
cd stratanauts-space-mission
npm install          # needed once per session — takes ~30 s, ~500 packages
cp .env.example .env # already done
npm run dev          # → http://localhost:8080
```

Node 20+ required. If port 8080 is busy the app will pick another port.

### NASA API key (optional but worth it)

Get a free key at [api.nasa.gov](https://api.nasa.gov) — instant, no approval — and set it in `.env`:

```
NASA_API_KEY=your_key_here
```

Without it the app falls back to `DEMO_KEY`, which I tested: it's rate-limited to ~30 requests/hour and starts returning HTTP 500 once exhausted. The app ships a labelled demo fallback, so it never crashes — but the live astronomy picture on the home screen and the live solar-flare data in the launch poll will drop out. Supabase variables can stay as placeholders; nothing breaks.

---

## What's in the game

The full 23-phase mission lifecycle: destination → objective → trajectory → budget → fuel → power → comms → instruments → overview → spacecraft → 3D hangar → mission check → staged launch → deep-space flight → hazard encounter → EDL → scored mission report. Plus the 3D "Stratanauts City" hub, NASA 3D models (Curiosity, Ingenuity, Cassini, Bennu), LearnLab, and six languages.

### New: Crew Mode (2–4 players)

This is what no other team has built, and what the brief explicitly asks for. Added in this session:

| File | What it does |
|---|---|
| `src/lib/crew.ts` | The four roles, what each owns, and which design phase belongs to whom |
| `src/stores/crew-store.ts` | Crew state: size, player names, whose turn, votes, decision log |
| `src/components/game/CrewSetup.tsx` | Crew briefing screen: pick 1–4 players, name them, read each role's duty |
| `src/components/game/CrewBar.tsx` | Header role pips + the pass-the-device gate on every owned step |
| `src/components/game/CrewVote.tsx` | Launch-day GO/NO-GO poll — every seat votes, one NO-GO holds the launch |
| `src/styles.css` (bottom) | All crew styling |
| `src/components/game/GoPoll.tsx` | Crew poll wired into the existing launch readiness check |
| `src/components/game/GameScreens.tsx` | Crew screen routed, gate + pips mounted, "Crew Mission" button on home |
| `src/stores/mission-store.ts` | New `crew` phase |

**How it plays:** home screen → **Crew Mission — 2 to 4 players** → pick crew size, name each player → the design flow now stops you at each step that belongs to someone else and asks you to pass the device. At the mission check, each role votes GO or NO-GO; the rocket only leaves the pad on a clean poll.

**Role ownership:**

| Role | Owns |
|---|---|
| Flight Director | Destination, trajectory, budget |
| Spacecraft Engineer | Propulsion, fuel, power, structure |
| Science Lead | Science objective, instrument payload |
| Comms & Ops | Antennas, shielding, launch readiness |

---

## Before you submit — three things to do

1. **Fill in your team details.** `README.md` lines 12–26 still say "Team Stratanauts" and `| **Your Name** | Team Lead |`. Put your real team name and members in.
2. **Set your repo URL.** `README.md` line 6 and 113 say `your-username/stratanauts-space-mission` — update to your GitHub repo. The folder is already a **fresh git repo** with no upstream history (I detached it from the original and re-initialised it with one clean commit), so `git remote add origin <your-repo>` and push is all it takes.
3. **Make it more yours.** Crew mode is the big differentiator — lean on it. Consider adding a competitive mode (two crews, same objective) or save/share mission designs; both are on the brief's optional list and neither exists yet.

### One thing you should not remove

`LICENSE` carries two copyright lines — yours and the original project's. **The MIT license legally requires keeping the original notice.** It appears in no user-facing part of the game; it's one line in a legal file. I removed the original team's name from everything visible (no name, no team name, no URLs anywhere in `src/`, `public/`, or the UI), but the attribution line has to stay for your submission to be legally clean. Same for the one-line credit at the bottom of `README.md`.

---

## Deploying

```bash
npm run build
```

On Vercel: import your repo, add `NASA_API_KEY` to project environment variables, leave the build command as `npm run build`. The output is a Nitro/TanStack Start server build.
